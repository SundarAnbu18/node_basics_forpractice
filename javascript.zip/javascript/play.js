var name='Sundar Anbu';
let age=20 //it can replaced again with the same name
const hobby=true;  //it can't be replaced again with the same name

// function sundar(username,userage,userhobby){                   //terriational way of creating function
//     return (
//         'my name is'+
//         username+'and i am '+
//         userage+'years old'+
//         'Do you have hobbies'+
//         userhobby
//     )
// }

// const sundar=function(username,userage,userhobby){          // instead of writing the function name behind the function keywork we can also assign it as a variable and we can work in that way
//     return(
//         'my name is'+
//         username+'and i am '+
//         userage+'years old'+
//         'Do you have hobbies'+
//         userhobby
//     )
// }

const sundar=(username,userage,userhobby)=>{           //This is arrow function with is latest in ES6 where we will use => to replace the function keyword and much more
    return(
        'my name is'+
                username+'and i am '+
                userage+'years old'+
                'Do you have hobbies'+
                userhobby
    )
}

const add =(a,b)=> a+b;   //by using the arrow function we can make our function creation very easy

const addone=a=>a+1;      //for the single parameters we don't need parameters
const addrandom=()=>100+19999 //for the empty parameter function also we need to empty parentesis

console.log(addone(100)); 

console.log(add(2,9))
console.log(addrandom())


console.log(sundar(name,age,hobby))