const sundar={                                 // Object is used to rapup the thing together into single object
    name:'Sundar Anbu',
    age:'20',
    Girl_Friend_Name:'Shilpa Queen',
    shilpa(){
        console.log('my name is ',this.Girl_Friend_Name)
    }
}

sundar.shilpa();

//array

const sundar_anbu=[87,67,];     //we will define the array inside the []
// for(let anbu of sundar_anbu){
//     console.log(anbu)
// }

const isLarges=(element)=>element>1

console.log(sundar_anbu.findIndex(isLarges));