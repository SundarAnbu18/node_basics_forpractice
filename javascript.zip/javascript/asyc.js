setTimeout(()=>{                      //async code will take some time and then it will execute    
    console.log("Sundar Anbu")
},0)

console.log('Anbu')      //syncrize code will executge first 
console.log('Sundar')