const person={
    name:'Shilpa Queen',
    age:20,
    living_place:'Kondam Kariyandal'
}
console.log(person)

const data=({name})=>{
    console.log(name)
}
data(person);