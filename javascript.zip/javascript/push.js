const hobby=['Watching Videos','Making Video']
hobby.push('Programming')
const copy=hobby.slice(2);
console.log(hobby)
console.log(copy)


//sprit operator

const person={
    name:'Sundar Anbu',
    age:'20',
    data:'Sundar Anbu is from Deliforce'
}

const copied={...person}
console.log(copied)


const array=(...arg)=>{
    return arg
}

console.log(array('sundar anbu',23,'Data of Data'))